import json
import util.response as Res


def lambda_handler(event, context):
    res = Res.response()
    return res