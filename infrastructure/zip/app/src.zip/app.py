import json


def lambda_handler(event, context):
    #res = Res.response()
    #return res
    return {
        response: "200"
    }